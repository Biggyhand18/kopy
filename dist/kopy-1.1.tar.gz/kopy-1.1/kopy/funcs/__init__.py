from kopy.funcs.kopy_func import KoPy_func
from kopy.funcs.utils import *

__all__ = ['KoPy_func']