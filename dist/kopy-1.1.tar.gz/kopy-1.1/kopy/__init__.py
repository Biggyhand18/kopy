try:
    from kopy.kopy import KoPy
except:
    from kopy import KoPy

__all__ = ['KoPy']
__version__ = '1.0'